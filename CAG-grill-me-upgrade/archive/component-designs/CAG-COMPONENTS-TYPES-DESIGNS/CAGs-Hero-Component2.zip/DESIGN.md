---
name: Terracotta Warmth
colors:
  surface: '#fff8f6'
  surface-dim: '#ecd5d1'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0ee'
  surface-container: '#ffe9e5'
  surface-container-high: '#fbe3df'
  surface-container-highest: '#f5ddd9'
  on-surface: '#251916'
  on-surface-variant: '#58413d'
  inverse-surface: '#3b2d2b'
  inverse-on-surface: '#ffedea'
  outline: '#8c716c'
  outline-variant: '#e0bfba'
  surface-tint: '#ab3425'
  primary: '#a83222'
  on-primary: '#ffffff'
  primary-container: '#c94a38'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb4a7'
  secondary: '#2c694e'
  on-secondary: '#ffffff'
  secondary-container: '#aeeecb'
  on-secondary-container: '#316e52'
  tertiary: '#006763'
  on-tertiary: '#ffffff'
  tertiary-container: '#00837d'
  on-tertiary-container: '#f3fffd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a7'
  on-primary-fixed: '#400100'
  on-primary-fixed-variant: '#8a1c10'
  secondary-fixed: '#b1f0ce'
  secondary-fixed-dim: '#95d4b3'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#0e5138'
  tertiary-fixed: '#81f5ed'
  tertiary-fixed-dim: '#63d9d1'
  on-tertiary-fixed: '#00201e'
  on-tertiary-fixed-variant: '#00504c'
  background: '#fff8f6'
  on-background: '#251916'
  surface-variant: '#f5ddd9'
  clay: '#e8604c'
  clay-light: '#f08070'
  clay-dark: '#c94d3a'
  forest: '#2D6A4F'
  forest-light: '#eaf4ef'
  cream: '#faf7f4'
  warm-white: '#fff9f6'
  border: '#ede5dc'
  text-main: '#1c1a18'
  text-mid: '#5a5248'
  text-light: '#9b9189'
typography:
  headline-xl:
    fontFamily: Lora
    fontSize: 3.2rem
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Lora
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Lora
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: '1.4'
  body-default:
    fontFamily: Sora
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Sora
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
  label-sm:
    fontFamily: Sora
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1.2'
  tag-uppercase:
    fontFamily: Sora
    fontSize: 11px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 1px
  caption:
    fontFamily: Sora
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
  headline-xl-mobile:
    fontFamily: Lora
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  2xl: 64px
  3xl: 96px
---

# CAG Design System

Derived from the contact-us page rebuild (Design B — "Terracotta Warmth").
Apply this system to every page, component, navbar, and footer rebuild.

---

## Brand Identity

**Site:** CongoAfricanGreys.com  
**Tone:** Warm, trustworthy, premium — like a high-end pet boutique, not a generic directory.  
**Target:** Parrot buyers (first-timers and experienced) seeking CITES-documented, captive-bred birds.

---

## Typography

| Role | Font | Weight | Size |
|---|---|---|---|
| Page H1, card H2 | Lora (serif, italic available) | 700 | 2–3.2rem |
| Section H2 | Lora | 700 | 1.5–2rem |
| Card/form H2 | Lora | 700 | 1.5rem |
| Body copy | Sora | 400 | 1rem / 16px |
| Labels, nav links | Sora | 500–700 | 13–14px |
| Uppercase tags | Sora | 700 | 11–12px, letter-spacing 1px |
| Meta/caption | Sora | 400 | 12–13px |

**Google Fonts import (add to every page `<head>`):**
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&family=Lora:ital,wght@0,400;0,600;0,700;1,400;1,600&display=swap" rel="stylesheet">
```

---

## Color Palette

### ✅ Active Website Colors (confirmed production — do not change)

| Role | Color | Hex | Tailwind token |
|------|-------|-----|---------------|
| **Brand Green** — header/nav background, section headers | Forest green | `#2D6A4F` | `bg-green` / `text-green` |
| **Orange (Clay)** — all CTAs, buttons, active accents, gold text | Terracotta orange | `#e8604c` | `bg-clay` / `text-clay` / `text-gold` |
| **White / Cream** — page background, card surfaces | Off-white | `#faf7f4` | `bg-warm-white` / `bg-white` |

> **Rule:** `--color-gold` in `src/styles/global.css` must always equal `#e8604c` (same as `--color-clay`). This ensures every `text-gold`, `bg-gold`, `border-gold` renders orange, not yellow.

```css
:root {
  /* Brand */
  --clay:       #e8604c;   /* Primary CTA / buttons / active accents */
  --clay-lt:    #f08070;   /* Gradient light / hover */
  --clay-dk:    #c94d3a;   /* Pressed / deep hover */
  --green:      #2D6A4F;   /* Brand green — header bg, info headers, labels */
  --green-lt:   #eaf4ef;   /* Light green — success bg, tag bg */
  --gold:       #e8604c;   /* ⚠️ Must equal clay — all gold text is orange */

  /* Surfaces */
  --cream:      #faf7f4;   /* Page background */
  --warm-white: #fff9f6;   /* Form inputs, inner card bg */
  --card-bg:    #ffffff;   /* Card surfaces */
  --border:     #ede5dc;   /* All borders and dividers */

  /* Text */
  --text:       #1c1a18;   /* Primary — near-black warm */
  --mid:        #5a5248;   /* Secondary — body paragraphs */
  --light:      #9b9189;   /* Tertiary — placeholder, captions */

  /* Dark panels */
  --dark-panel: #1c1a18;   /* CTA banners, dark footer */
  --forest:     #2D6A4F;   /* Info card headers, dark nav variant */
}
```

---

## Spacing Scale

| Token | Value | Use |
|---|---|---|
| xs | 4px | icon gaps, tight inline |
| sm | 8px | pill padding, small gaps |
| md | 16px | field margin-bottom, grid gap |
| lg | 24px | card inner padding top/bottom |
| xl | 40px | section padding sides |
| 2xl | 64px | section top/bottom padding |
| 3xl | 96px | hero section padding |

---

## Border Radius Scale

| Token | Value | Use |
|---|---|---|
| sm | 8px | small badges, social buttons |
| md | 10px | form inputs, small cards |
| lg | 14px | map info boxes, icon wrappers |
| xl | 20px | cards, info panel |
| pill | 50px | CTA buttons, trust pills, tags |

---

## Shadows

```css
--shadow:    0 2px 16px rgba(60,30,10,.08), 0 8px 40px rgba(60,30,10,.06);
--shadow-lg: 0 4px 24px rgba(60,30,10,.1), 0 16px 56px rgba(60,30,10,.08);
--shadow-btn: 0 6px 20px rgba(232,96,76,.38);  /* clay button glow */
```

---

## Buttons

### Primary (Clay)
```css
background: #e8604c; color: #fff; border: none;
padding: 14px 32px; border-radius: 50px;
font: 700 15px/1 'Sora', sans-serif; letter-spacing: .2px;
box-shadow: 0 6px 20px rgba(232,96,76,.38);
transition: background .2s, transform .15s, box-shadow .2s;
```
Hover: `background: #c94d3a; transform: translateY(-2px); box-shadow: 0 10px 28px rgba(232,96,76,.48);`

### Primary Rounded-Square (forms)
Same as above but `border-radius: 12px` instead of `50px`.

### Outline
```css
background: transparent; color: #e8604c;
border: 2px solid #e8604c; padding: 12px 28px; border-radius: 50px;
font: 700 14px/1 'Sora', sans-serif;
```
Hover: fill with `#e8604c`, `color: #fff`.

### Green Tag / Badge
```css
background: #eaf4ef; color: #2D6A4F;
border: 1px solid rgba(45,106,79,.2);
padding: 5px 14px; border-radius: 50px;
font: 700 11px/1 'Sora', sans-serif; letter-spacing: 1px; text-transform: uppercase;
```

---

## Form Inputs

```css
/* All inputs, selects, textareas */
padding: 12px 16px;
border: 1.5px solid #ede5dc;
border-radius: 10px;
font: 400 14.5px/1.4 'Sora', sans-serif;
background: #fff9f6; color: #1c1a18;
transition: border-color .2s, box-shadow .2s, background .2s;
outline: none;

/* Focus */
border-color: #e8604c;
box-shadow: 0 0 0 3px rgba(232,96,76,.1);
background: #ffffff;

/* Labels */
font: 700 12px/1 'Sora', sans-serif;
text-transform: uppercase; letter-spacing: .7px;
color: #1c1a18; margin-bottom: 7px;
```

### Pill Selectors (radio/checkbox groups)
```css
/* Option pill */
display: flex; align-items: center; gap: 8px;
background: #fff9f6; border: 1.5px solid #ede5dc;
border-radius: 10px; padding: 9px 16px;
font: 400 13.5px/1 'Sora', sans-serif; color: #5a5248;
cursor: pointer; transition: all .15s;

/* Checked state */
background: #fff3ef; border-color: #e8604c;
color: #c94d3a; font-weight: 600;
```

---

## Cards

```css
/* Standard card */
background: #ffffff;
border-radius: 20px;
border: 1px solid #ede5dc;
box-shadow: 0 2px 16px rgba(60,30,10,.08), 0 8px 40px rgba(60,30,10,.06);
overflow: hidden;

/* Green header variant (info card) */
.card-header-green {
  background: #2D6A4F; padding: 32px 28px;
  color: #fff;
}
```

---

## Section Patterns

### Page Hero Banner (warm gradient)
```css
background: linear-gradient(135deg, #fde8e3 0%, #fdf0e8 50%, #fdf6ec 100%);
padding: 64px 48px 72px; text-align: center;
border-bottom: 1px solid #f0e4da;
```

### Dark CTA Banner (bottom-of-page)
```css
background: #1c1a18; padding: 72px 48px; text-align: center;
h2: font-family Lora, 2.8rem, color #e8604c, uppercase, letter-spacing 2px;
```

### Map Section
```css
background: #ffffff;
border-top: 1px solid #ede5dc;
```

---

## Page Layout

- Max content width: **1180px**, `margin: 0 auto`
- Default section padding: **64px 48px**
- Mobile breakpoint: **768px** → single column, padding 40px 24px
- Tablet breakpoint: **1024px** → stack two-column grids

---

## Icons / Emoji System
Use emoji as functional icons (no icon library dependency):
- 📞 Phone  ✉️ Email  📍 Location  🕐 Hours  ✈️ Air shipping  🚗 Delivery
- 🦜 Parrot brand icon  ✅ Confirmation  ❋ Section divider (decorative)

---

## Trust Signals (standard set)
Always include at least two on every transactional page:
- "USDA-Licensed Breeder"
- "CITES Appendix II Documented"
- "DNA-Sexed & Vet-Certified"
- "Ships Nationwide from $185"
- "24–48 Hour Response Guarantee"
- "Health Guarantee on Every Bird"

---

## Anti-Copy: DISABLED
All `user-select: none` CSS and `wpcp_css_disable_selection` JS have been removed from all pages. Never add them back. Visitors must be able to select and copy text.

---

## Formspree Endpoints
| Page | Endpoint |
|---|---|
| /contact-us/ | `https://formspree.io/f/xrejpnvn` |
| All product pages | `https://formspree.io/f/xpqoeazq` |
| Newsletter | `https://formspree.io/f/xpqoeazq` |

---

## File Locations
| Asset | Path |
|---|---|
| Logo image | `/wp-content/uploads/african-grey-parrot-store-logo.png` |
| Contact page | `site/content/contact-us/index.html` |
| Design system | `docs/design.md` (this file) |
| Contact form skill | `skills/cag-contact-form.md` |